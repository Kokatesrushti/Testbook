import { pgTable, text, serial, integer, boolean, timestamp, json, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  profilePicture: text("profile_picture"),
  role: text("role").default("user").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  name: true,
  profilePicture: true,
});

// Course Category model
export const courseCategories = pgTable("course_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  testsAvailable: integer("tests_available").notNull().default(0),
});

export const insertCourseCategorySchema = createInsertSchema(courseCategories).pick({
  name: true,
  slug: true,
  description: true,
  icon: true,
  color: true,
  testsAvailable: true,
});

// Course model
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  categoryId: integer("category_id").notNull(),
  image: text("image").notNull(),
  price: integer("price").notNull(),
  originalPrice: integer("original_price").notNull(),
  rating: integer("rating").default(0),
  reviewCount: integer("review_count").default(0),
  isBestSeller: boolean("is_best_seller").default(false),
  isNew: boolean("is_new").default(false),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertCourseSchema = createInsertSchema(courses).pick({
  title: true,
  slug: true,
  description: true,
  categoryId: true,
  image: true,
  price: true,
  originalPrice: true,
  rating: true,
  reviewCount: true,
  isBestSeller: true,
  isNew: true,
});

// Mock Test model
export const mockTests = pgTable("mock_tests", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  categoryId: integer("category_id").notNull(),
  duration: integer("duration").notNull(), // in minutes
  questionCount: integer("question_count").notNull(),
  languages: text("languages").array().notNull(),
  attemptCount: integer("attempt_count").default(0),
  isFree: boolean("is_free").default(false),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertMockTestSchema = createInsertSchema(mockTests).pick({
  title: true,
  slug: true,
  categoryId: true,
  duration: true,
  questionCount: true,
  languages: true,
  attemptCount: true,
  isFree: true,
});

// Mock Test Question model
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  testId: integer("test_id").notNull(),
  content: text("content").notNull(),
  options: json("options").notNull(), // Array of options
  correctOption: integer("correct_option").notNull(),
  explanation: text("explanation"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertQuestionSchema = createInsertSchema(questions).pick({
  testId: true,
  content: true,
  options: true,
  correctOption: true,
  explanation: true,
});

// User Test Attempt model
export const testAttempts = pgTable("test_attempts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  testId: integer("test_id").notNull(),
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  answers: json("answers").notNull(), // User answers
  timeSpent: integer("time_spent").notNull(), // in seconds
  completedAt: timestamp("completed_at").defaultNow()
});

export const insertTestAttemptSchema = createInsertSchema(testAttempts).pick({
  userId: true,
  testId: true,
  score: true,
  totalQuestions: true,
  answers: true,
  timeSpent: true,
});

// User Course Enrollment model
export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  courseId: integer("course_id").notNull(),
  enrolledAt: timestamp("enrolled_at").defaultNow(),
  progress: integer("progress").default(0),
  isCompleted: boolean("is_completed").default(false),
});

export const insertEnrollmentSchema = createInsertSchema(enrollments).pick({
  userId: true,
  courseId: true,
  progress: true,
  isCompleted: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type CourseCategory = typeof courseCategories.$inferSelect;
export type InsertCourseCategory = z.infer<typeof insertCourseCategorySchema>;

export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export type MockTest = typeof mockTests.$inferSelect;
export type InsertMockTest = z.infer<typeof insertMockTestSchema>;

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;

export type TestAttempt = typeof testAttempts.$inferSelect;
export type InsertTestAttempt = z.infer<typeof insertTestAttemptSchema>;

export type Enrollment = typeof enrollments.$inferSelect;
export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
