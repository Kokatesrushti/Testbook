import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertEnrollmentSchema, 
  insertTestAttemptSchema 
} from "@shared/schema";
import { z } from "zod";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import session from "express-session";
import MemoryStore from "memorystore";

// Create session store
const SessionStore = MemoryStore(session);

// Auth middleware
const authenticateToken = (req: Request, res: Response, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: "No token provided" });
  }

  const JWT_SECRET = process.env.JWT_SECRET || "edutest-secret-key";
  
  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: "Invalid or expired token" });
    }
    
    (req as any).user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure sessions
  app.use(session({
    cookie: { maxAge: 86400000 },
    store: new SessionStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    resave: false,
    saveUninitialized: false,
    secret: process.env.SESSION_SECRET || "edutest-session-secret"
  }));

  // Authentication
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }

      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(userData.password, salt);
      
      // Create user with hashed password
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Remove password from response
      const userResponse = { ...user };
      delete userResponse.password;
      
      res.status(201).json(userResponse);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      // Find user
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Check password
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Create token
      const JWT_SECRET = process.env.JWT_SECRET || "edutest-secret-key";
      const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, {
        expiresIn: "1d"
      });
      
      // Remove password from response
      const userResponse = { ...user };
      delete userResponse.password;
      
      res.json({ token, user: userResponse });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req, res) => {
    try {
      const userId = (req as any).user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const userResponse = { ...user };
      delete userResponse.password;
      
      res.json(userResponse);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/categories/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const category = await storage.getCategoryBySlug(slug);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Courses
  app.get("/api/courses", async (req, res) => {
    try {
      const { category } = req.query;
      let courses;
      
      if (category) {
        const categoryObj = await storage.getCategoryBySlug(category as string);
        if (categoryObj) {
          courses = await storage.getCoursesByCategory(categoryObj.id);
        } else {
          courses = [];
        }
      } else {
        courses = await storage.getCourses();
      }
      
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/courses/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const course = await storage.getCourseBySlug(slug);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(course);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Mock Tests
  app.get("/api/mock-tests", async (req, res) => {
    try {
      const { category } = req.query;
      let tests;
      
      if (category) {
        const categoryObj = await storage.getCategoryBySlug(category as string);
        if (categoryObj) {
          tests = await storage.getMockTestsByCategory(categoryObj.id);
        } else {
          tests = [];
        }
      } else {
        tests = await storage.getMockTests();
      }
      
      res.json(tests);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/mock-tests/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const test = await storage.getMockTestBySlug(slug);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      res.json(test);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/mock-tests/:id/questions", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const testId = parseInt(id);
      
      // Check if test exists
      const test = await storage.getMockTestById(testId);
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      const questions = await storage.getQuestionsByTestId(testId);
      
      // For now, if no questions exist, generate some sample questions
      if (questions.length === 0) {
        // This is just for demo purposes, in a real app we'd have proper questions
        const sampleQuestions = [];
        for (let i = 1; i <= 5; i++) {
          const question = await storage.createQuestion({
            testId,
            content: `Sample question ${i} for test "${test.title}"`,
            options: [
              "Option A",
              "Option B",
              "Option C",
              "Option D"
            ],
            correctOption: 0, // Index of the correct option (Option A)
            explanation: `Explanation for question ${i}`
          });
          sampleQuestions.push(question);
        }
        
        res.json(sampleQuestions);
      } else {
        res.json(questions);
      }
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Enrollments
  app.post("/api/enrollments", authenticateToken, async (req, res) => {
    try {
      const userId = (req as any).user.id;
      const enrollmentData = insertEnrollmentSchema.parse({
        ...req.body,
        userId
      });
      
      // Check if course exists
      const course = await storage.getCourseById(enrollmentData.courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Create enrollment
      const enrollment = await storage.createEnrollment(enrollmentData);
      
      res.status(201).json(enrollment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/enrollments", authenticateToken, async (req, res) => {
    try {
      const userId = (req as any).user.id;
      const enrollments = await storage.getEnrollmentsByUserId(userId);
      
      // Get course details for each enrollment
      const enrollmentsWithCourses = await Promise.all(
        enrollments.map(async (enrollment) => {
          const course = await storage.getCourseById(enrollment.courseId);
          return {
            ...enrollment,
            course
          };
        })
      );
      
      res.json(enrollmentsWithCourses);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/enrollments/:id/progress", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const { progress, isCompleted } = req.body;
      
      const userId = (req as any).user.id;
      const enrollments = await storage.getEnrollmentsByUserId(userId);
      
      // Check if enrollment exists and belongs to user
      const enrollmentId = parseInt(id);
      const enrollment = enrollments.find(e => e.id === enrollmentId);
      
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      // Update progress
      const updatedEnrollment = await storage.updateEnrollmentProgress(
        enrollmentId,
        progress || enrollment.progress,
        isCompleted !== undefined ? isCompleted : enrollment.isCompleted
      );
      
      res.json(updatedEnrollment);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Test Attempts
  app.post("/api/test-attempts", authenticateToken, async (req, res) => {
    try {
      const userId = (req as any).user.id;
      const attemptData = insertTestAttemptSchema.parse({
        ...req.body,
        userId
      });
      
      // Check if test exists
      const test = await storage.getMockTestById(attemptData.testId);
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      // Create test attempt
      const attempt = await storage.createTestAttempt(attemptData);
      
      res.status(201).json(attempt);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/test-attempts", authenticateToken, async (req, res) => {
    try {
      const userId = (req as any).user.id;
      const attempts = await storage.getTestAttemptsByUserId(userId);
      
      // Get test details for each attempt
      const attemptsWithTests = await Promise.all(
        attempts.map(async (attempt) => {
          const test = await storage.getMockTestById(attempt.testId);
          return {
            ...attempt,
            test
          };
        })
      );
      
      res.json(attemptsWithTests);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
