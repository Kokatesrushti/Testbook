import { 
  users, User, InsertUser,
  courseCategories, CourseCategory, InsertCourseCategory,
  courses, Course, InsertCourse,
  mockTests, MockTest, InsertMockTest,
  questions, Question, InsertQuestion,
  testAttempts, TestAttempt, InsertTestAttempt,
  enrollments, Enrollment, InsertEnrollment
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Course category methods
  getCategories(): Promise<CourseCategory[]>;
  getCategoryBySlug(slug: string): Promise<CourseCategory | undefined>;
  getCategoryById(id: number): Promise<CourseCategory | undefined>;
  createCategory(category: InsertCourseCategory): Promise<CourseCategory>;
  
  // Course methods
  getCourses(): Promise<Course[]>;
  getCoursesByCategory(categoryId: number): Promise<Course[]>;
  getCourseBySlug(slug: string): Promise<Course | undefined>;
  getCourseById(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Mock test methods
  getMockTests(): Promise<MockTest[]>;
  getMockTestsByCategory(categoryId: number): Promise<MockTest[]>;
  getMockTestBySlug(slug: string): Promise<MockTest | undefined>;
  getMockTestById(id: number): Promise<MockTest | undefined>;
  createMockTest(test: InsertMockTest): Promise<MockTest>;
  
  // Question methods
  getQuestionsByTestId(testId: number): Promise<Question[]>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  
  // Test attempt methods
  createTestAttempt(attempt: InsertTestAttempt): Promise<TestAttempt>;
  getTestAttemptsByUserId(userId: number): Promise<TestAttempt[]>;
  
  // Enrollment methods
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  getEnrollmentsByUserId(userId: number): Promise<Enrollment[]>;
  updateEnrollmentProgress(id: number, progress: number, isCompleted: boolean): Promise<Enrollment>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, CourseCategory>;
  private courses: Map<number, Course>;
  private mockTests: Map<number, MockTest>;
  private questions: Map<number, Question>;
  private testAttempts: Map<number, TestAttempt>;
  private enrollments: Map<number, Enrollment>;
  private currentIds: {
    users: number;
    categories: number;
    courses: number;
    mockTests: number;
    questions: number;
    testAttempts: number;
    enrollments: number;
  };

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.courses = new Map();
    this.mockTests = new Map();
    this.questions = new Map();
    this.testAttempts = new Map();
    this.enrollments = new Map();
    this.currentIds = {
      users: 1,
      categories: 1,
      courses: 1,
      mockTests: 1,
      questions: 1,
      testAttempts: 1,
      enrollments: 1,
    };
    
    // Add sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Add sample categories
    const bankingCategory = this.createCategory({
      name: "Banking Exams",
      slug: "banking-exams",
      description: "SBI, IBPS, RBI & more",
      icon: "landmark",
      color: "blue",
      testsAvailable: 15
    });
    
    const sscCategory = this.createCategory({
      name: "SSC & Railways",
      slug: "ssc-railways",
      description: "CGL, CHSL, RRB & more",
      icon: "train",
      color: "green",
      testsAvailable: 20
    });
    
    const engineeringCategory = this.createCategory({
      name: "JEE & NEET",
      slug: "jee-neet",
      description: "Engineering & Medical",
      icon: "graduation-cap",
      color: "red",
      testsAvailable: 25
    });
    
    const upscCategory = this.createCategory({
      name: "UPSC & Civil Services",
      slug: "upsc-civil-services",
      description: "IAS, IPS & more",
      icon: "balance-scale",
      color: "yellow",
      testsAvailable: 18
    });
    
    // Add sample courses
    this.createCourse({
      title: "Complete Banking Exam Preparation",
      slug: "complete-banking-exam-preparation",
      description: "Comprehensive course for SBI, IBPS, RBI, and other banking exams",
      categoryId: bankingCategory.id,
      image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=340",
      price: 2499,
      originalPrice: 4999,
      rating: 49,
      reviewCount: 120,
      isBestSeller: true,
      isNew: false
    });
    
    this.createCourse({
      title: "SSC CGL Complete Course",
      slug: "ssc-cgl-complete-course",
      description: "Full preparation for Staff Selection Commission Combined Graduate Level Examination",
      categoryId: sscCategory.id,
      image: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=340",
      price: 1999,
      originalPrice: 3999,
      rating: 48,
      reviewCount: 98,
      isBestSeller: false,
      isNew: false
    });
    
    this.createCourse({
      title: "JEE Advanced Master Course",
      slug: "jee-advanced-master-course",
      description: "Complete preparation for JEE Advanced with problem-solving techniques",
      categoryId: engineeringCategory.id,
      image: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=340",
      price: 3499,
      originalPrice: 5999,
      rating: 47,
      reviewCount: 85,
      isBestSeller: false,
      isNew: true
    });
    
    this.createCourse({
      title: "UPSC CSE Foundation Course",
      slug: "upsc-cse-foundation-course",
      description: "Structured preparation for Civil Services Examination from basics to advanced",
      categoryId: upscCategory.id,
      image: "https://images.unsplash.com/photo-1513258496099-48168024aec0?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=340",
      price: 4999,
      originalPrice: 7999,
      rating: 49,
      reviewCount: 112,
      isBestSeller: false,
      isNew: false
    });
    
    // Add sample mock tests
    this.createMockTest({
      title: "SBI PO Prelims Mock Test",
      slug: "sbi-po-prelims-mock-test",
      categoryId: bankingCategory.id,
      duration: 60,
      questionCount: 100,
      languages: ["English", "Hindi"],
      attemptCount: 7500,
      isFree: true
    });
    
    this.createMockTest({
      title: "SSC CGL Tier 1 Mock Test",
      slug: "ssc-cgl-tier-1-mock-test",
      categoryId: sscCategory.id,
      duration: 60,
      questionCount: 100,
      languages: ["English", "Hindi"],
      attemptCount: 6000,
      isFree: true
    });
    
    this.createMockTest({
      title: "RRB NTPC CBT-1 Mock Test",
      slug: "rrb-ntpc-cbt-1-mock-test",
      categoryId: sscCategory.id,
      duration: 90,
      questionCount: 100,
      languages: ["English", "Hindi"],
      attemptCount: 8500,
      isFree: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.users++;
    const user: User = { ...insertUser, id, role: "user" };
    this.users.set(id, user);
    return user;
  }
  
  // Course category methods
  async getCategories(): Promise<CourseCategory[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategoryBySlug(slug: string): Promise<CourseCategory | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug,
    );
  }
  
  async getCategoryById(id: number): Promise<CourseCategory | undefined> {
    return this.categories.get(id);
  }
  
  async createCategory(insertCategory: InsertCourseCategory): Promise<CourseCategory> {
    const id = this.currentIds.categories++;
    const category: CourseCategory = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }
  
  // Course methods
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }
  
  async getCoursesByCategory(categoryId: number): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      (course) => course.categoryId === categoryId,
    );
  }
  
  async getCourseBySlug(slug: string): Promise<Course | undefined> {
    return Array.from(this.courses.values()).find(
      (course) => course.slug === slug,
    );
  }
  
  async getCourseById(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }
  
  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = this.currentIds.courses++;
    const course: Course = { 
      ...insertCourse, 
      id, 
      createdAt: new Date() 
    };
    this.courses.set(id, course);
    return course;
  }
  
  // Mock test methods
  async getMockTests(): Promise<MockTest[]> {
    return Array.from(this.mockTests.values());
  }
  
  async getMockTestsByCategory(categoryId: number): Promise<MockTest[]> {
    return Array.from(this.mockTests.values()).filter(
      (test) => test.categoryId === categoryId,
    );
  }
  
  async getMockTestBySlug(slug: string): Promise<MockTest | undefined> {
    return Array.from(this.mockTests.values()).find(
      (test) => test.slug === slug,
    );
  }
  
  async getMockTestById(id: number): Promise<MockTest | undefined> {
    return this.mockTests.get(id);
  }
  
  async createMockTest(insertTest: InsertMockTest): Promise<MockTest> {
    const id = this.currentIds.mockTests++;
    const test: MockTest = { 
      ...insertTest, 
      id, 
      createdAt: new Date() 
    };
    this.mockTests.set(id, test);
    return test;
  }
  
  // Question methods
  async getQuestionsByTestId(testId: number): Promise<Question[]> {
    return Array.from(this.questions.values()).filter(
      (question) => question.testId === testId,
    );
  }
  
  async createQuestion(insertQuestion: InsertQuestion): Promise<Question> {
    const id = this.currentIds.questions++;
    const question: Question = { 
      ...insertQuestion, 
      id, 
      createdAt: new Date() 
    };
    this.questions.set(id, question);
    return question;
  }
  
  // Test attempt methods
  async createTestAttempt(insertAttempt: InsertTestAttempt): Promise<TestAttempt> {
    const id = this.currentIds.testAttempts++;
    const attempt: TestAttempt = { 
      ...insertAttempt, 
      id, 
      completedAt: new Date() 
    };
    this.testAttempts.set(id, attempt);
    return attempt;
  }
  
  async getTestAttemptsByUserId(userId: number): Promise<TestAttempt[]> {
    return Array.from(this.testAttempts.values()).filter(
      (attempt) => attempt.userId === userId,
    );
  }
  
  // Enrollment methods
  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const id = this.currentIds.enrollments++;
    const enrollment: Enrollment = { 
      ...insertEnrollment, 
      id, 
      enrolledAt: new Date()
    };
    this.enrollments.set(id, enrollment);
    return enrollment;
  }
  
  async getEnrollmentsByUserId(userId: number): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(
      (enrollment) => enrollment.userId === userId,
    );
  }
  
  async updateEnrollmentProgress(id: number, progress: number, isCompleted: boolean): Promise<Enrollment> {
    const enrollment = this.enrollments.get(id);
    if (!enrollment) {
      throw new Error("Enrollment not found");
    }
    
    const updatedEnrollment: Enrollment = {
      ...enrollment,
      progress,
      isCompleted
    };
    
    this.enrollments.set(id, updatedEnrollment);
    return updatedEnrollment;
  }
}

export const storage = new MemStorage();
