import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
 
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(price: number): string {
  return `₹${price.toLocaleString('en-IN')}`;
}

export function calculateDiscountPercentage(originalPrice: number, discountedPrice: number): number {
  if (originalPrice <= 0 || discountedPrice <= 0) return 0;
  const discount = ((originalPrice - discountedPrice) / originalPrice) * 100;
  return Math.round(discount);
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

export function getAcronym(text: string): string {
  return text
    .split(/\s+/)
    .map(word => word[0]?.toUpperCase() || '')
    .join('')
    .slice(0, 2);
}

export function formatDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (hours > 0) {
    return `${hours} hr${hours > 1 ? 's' : ''} ${mins > 0 ? `${mins} min` : ''}`;
  }
  
  return `${mins} min`;
}

export function formatAttemptCount(count: number): string {
  if (count >= 1000) {
    return `${(count / 1000).toFixed(1)}K`;
  }
  return count.toString();
}

// Get color class based on category
export function getCategoryColorClass(color: string): { bg: string; text: string } {
  const colorMap: Record<string, { bg: string; text: string }> = {
    blue: { bg: 'bg-blue-100', text: 'text-blue-800' },
    green: { bg: 'bg-green-100', text: 'text-green-800' },
    red: { bg: 'bg-red-100', text: 'text-red-800' },
    yellow: { bg: 'bg-yellow-100', text: 'text-yellow-800' },
    purple: { bg: 'bg-purple-100', text: 'text-purple-800' },
    pink: { bg: 'bg-pink-100', text: 'text-pink-800' },
    indigo: { bg: 'bg-indigo-100', text: 'text-indigo-800' },
    orange: { bg: 'bg-orange-100', text: 'text-orange-800' },
  };

  return colorMap[color] || { bg: 'bg-gray-100', text: 'text-gray-800' };
}

// Get icon component based on icon name (from Lucide)
export function getIconByName(iconName: string): string {
  return iconName || 'CircleHelp';
}
