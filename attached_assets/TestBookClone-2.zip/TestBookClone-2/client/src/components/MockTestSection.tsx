import React, { useState } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { MockTest } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { formatAttemptCount, formatDuration } from '@/lib/utils';
import { Clock, HelpCircle, Languages } from 'lucide-react';
import TestCard from '@/components/TestCard';

const MockTestSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  
  const { data: tests, isLoading, error } = useQuery({
    queryKey: ['/api/mock-tests'],
  });

  // Filter tests based on active category
  const filteredTests = React.useMemo(() => {
    if (!tests || !Array.isArray(tests)) return [];
    
    if (activeCategory === 'all') return tests;
    
    // This is a simplified example - in a real app you'd match by categoryId
    return tests.filter((test: MockTest) => {
      // Match category with active tab
      if (activeCategory === 'banking' && test.categoryId === 1) return true;
      if (activeCategory === 'ssc' && test.categoryId === 2) return true;
      if (activeCategory === 'railways' && test.categoryId === 2) return true;
      if (activeCategory === 'teaching' && test.categoryId === 3) return true;
      if (activeCategory === 'engineering' && test.categoryId === 3) return true;
      return false;
    });
  }, [tests, activeCategory]);

  if (isLoading) {
    return (
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <p>Loading mock tests...</p>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center text-red-500">
            <p>Error loading mock tests. Please try again later.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Free Mock Tests</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Practice with our exam-like mock tests to evaluate your preparation level
          </p>
        </div>
        
        {/* Mock Test Categories Tabs */}
        <div className="mb-8 flex flex-wrap justify-center">
          <Button 
            variant={activeCategory === 'all' ? 'default' : 'outline'}
            className="mr-2 mb-2"
            onClick={() => setActiveCategory('all')}
          >
            All Tests
          </Button>
          <Button 
            variant={activeCategory === 'banking' ? 'default' : 'outline'}
            className="mr-2 mb-2"
            onClick={() => setActiveCategory('banking')}
          >
            Banking
          </Button>
          <Button 
            variant={activeCategory === 'ssc' ? 'default' : 'outline'}
            className="mr-2 mb-2"
            onClick={() => setActiveCategory('ssc')}
          >
            SSC
          </Button>
          <Button 
            variant={activeCategory === 'railways' ? 'default' : 'outline'}
            className="mr-2 mb-2"
            onClick={() => setActiveCategory('railways')}
          >
            Railways
          </Button>
          <Button 
            variant={activeCategory === 'teaching' ? 'default' : 'outline'}
            className="mr-2 mb-2"
            onClick={() => setActiveCategory('teaching')}
          >
            Teaching
          </Button>
          <Button 
            variant={activeCategory === 'engineering' ? 'default' : 'outline'}
            className="mr-2 mb-2"
            onClick={() => setActiveCategory('engineering')}
          >
            Engineering
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTests.map((test: MockTest) => (
            <TestCard key={test.id} test={test} />
          ))}
        </div>
        
        <div className="text-center mt-10">
          <Button asChild variant="outline" className="border-primary text-primary hover:bg-primary/10">
            <Link href="/mock-tests">View All Mock Tests</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default MockTestSection;
