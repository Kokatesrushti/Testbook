import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';

const TestSeriesSection: React.FC = () => {
  const features = [
    {
      title: "Exam Pattern Based Tests",
      description: "All tests follow the latest exam pattern and syllabus"
    },
    {
      title: "Detailed Solutions",
      description: "Step-by-step explanations for all questions"
    },
    {
      title: "All-India Ranking",
      description: "Compare your performance with other aspirants across India"
    },
    {
      title: "Performance Analysis",
      description: "Detailed analytics to identify your strengths and weaknesses"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 mb-8 lg:mb-0 lg:pr-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Premium Test Series</h2>
            <p className="text-lg text-gray-600 mb-6">
              Prepare effectively with our comprehensive test series designed by experts. 
              Get detailed performance analysis and improve your score.
            </p>
            
            <div className="space-y-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start">
                  <div className="mt-1 mr-4 text-primary">
                    <CheckCircle className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <Button asChild className="bg-primary hover:bg-primary/90 text-white" size="lg">
              <Link href="/test-series">Explore Test Series</Link>
            </Button>
          </div>
          
          <div className="lg:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1516979187457-637abb4f9353?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&h=500" 
              alt="Student taking online test" 
              className="rounded-lg shadow-xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestSeriesSection;
