import React from 'react';
import { Link } from 'wouter';
import { MockTest } from '@shared/schema';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, HelpCircle, Languages } from 'lucide-react';
import { formatAttemptCount, formatDuration, getCategoryColorClass } from '@/lib/utils';

interface TestCardProps {
  test: MockTest;
}

const TestCard: React.FC<TestCardProps> = ({ test }) => {
  const { isAuthenticated } = useAuth();
  
  // Map category IDs to category names (simplified example)
  const getCategoryInfo = (categoryId: number) => {
    const categories: Record<number, { name: string; color: string }> = {
      1: { name: 'Banking', color: 'blue' },
      2: { name: 'SSC', color: 'yellow' },
      3: { name: 'Railways', color: 'red' },
      4: { name: 'Teaching', color: 'green' }
    };
    
    return categories[categoryId] || { name: 'Other', color: 'gray' };
  };
  
  const categoryInfo = getCategoryInfo(test.categoryId);
  const { bg, text } = getCategoryColorClass(categoryInfo.color);
  
  // Calculate the width of the progress bar based on attempt count
  const progressWidth = Math.min(100, Math.max(10, (test.attemptCount / 10000) * 100));
  
  return (
    <div className="bg-white rounded-lg border border-gray-200 hover:shadow-md transition-shadow overflow-hidden">
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <Badge variant="secondary" className={`${bg} ${text}`}>
            {categoryInfo.name}
          </Badge>
          {test.isFree && (
            <span className="text-green-600 text-sm font-medium">Free</span>
          )}
        </div>
        <h3 className="font-semibold text-lg mb-2 text-gray-900">{test.title}</h3>
        <div className="flex items-center text-sm text-gray-500 mb-4">
          <div className="flex items-center mr-4">
            <Clock className="mr-1 h-4 w-4" /> {formatDuration(test.duration)}
          </div>
          <div className="flex items-center mr-4">
            <HelpCircle className="mr-1 h-4 w-4" /> {test.questionCount} questions
          </div>
          <div className="flex items-center">
            <Languages className="mr-1 h-4 w-4" /> {test.languages.join(', ')}
          </div>
        </div>
        <div className="flex items-center mb-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full" 
              style={{ width: `${progressWidth}%` }}
            ></div>
          </div>
          <span className="ml-2 text-sm text-gray-600">{formatAttemptCount(test.attemptCount)} attempts</span>
        </div>
        <Button asChild className="w-full">
          <Link href={isAuthenticated ? `/test/${test.slug}` : "/login"}>
            Start Test
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default TestCard;
