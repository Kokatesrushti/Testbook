import React from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { CourseCategory } from '@shared/schema';
import { 
  Landmark, 
  Train, 
  GraduationCap, 
  Scale, 
  Presentation, 
  Cog, 
  Shield, 
  Building,
  ArrowRight,
  CircleHelp
} from 'lucide-react';

// Map category icons to Lucide icons
const getCategoryIcon = (iconName: string, size = 24) => {
  const iconMap: Record<string, React.ReactNode> = {
    'landmark': <Landmark size={size} />,
    'train': <Train size={size} />,
    'graduation-cap': <GraduationCap size={size} />,
    'balance-scale': <Scale size={size} />,
    'chalkboard-teacher': <Presentation size={size} />,
    'cogs': <Cog size={size} />,
    'shield-alt': <Shield size={size} />,
    'building': <Building size={size} />
  };
  
  return iconMap[iconName] || <CircleHelp size={size} />;
};

// Map category colors to TailwindCSS classes
const getCategoryColorClasses = (color: string) => {
  const colorMap: Record<string, string> = {
    'blue': 'bg-blue-100 text-blue-600',
    'green': 'bg-green-100 text-green-600',
    'red': 'bg-red-100 text-red-600',
    'yellow': 'bg-yellow-100 text-yellow-600',
    'purple': 'bg-purple-100 text-purple-600',
    'indigo': 'bg-indigo-100 text-indigo-600',
    'orange': 'bg-orange-100 text-orange-600'
  };
  
  return colorMap[color] || 'bg-gray-100 text-gray-600';
};

const ExamCategories: React.FC = () => {
  const { data: categories, isLoading, error } = useQuery({
    queryKey: ['/api/categories'],
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <p>Loading categories...</p>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center text-red-500">
            <p>Error loading categories. Please try again later.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Popular Exam Categories</h2>
            <p className="text-lg text-gray-600">Prepare for the most sought-after competitive exams across India</p>
          </div>
          <Link href="/exams">
            <a className="mt-4 md:mt-0 text-primary font-medium hover:text-primary/90 flex items-center">
              View all categories <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {categories && Array.isArray(categories) && categories.map((category: CourseCategory) => (
            <div key={category.id} className="bg-white rounded-lg border border-gray-200 hover:shadow-md transition-shadow p-6 text-center">
              <div className={`w-16 h-16 flex items-center justify-center mx-auto mb-4 ${getCategoryColorClasses(category.color)}`}>
                {getCategoryIcon(category.icon)}
              </div>
              <h3 className="text-lg font-semibold mb-1">{category.name}</h3>
              <p className="text-sm text-gray-500 mb-3">{category.description}</p>
              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                {category.testsAvailable}+ Tests Available
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExamCategories;
