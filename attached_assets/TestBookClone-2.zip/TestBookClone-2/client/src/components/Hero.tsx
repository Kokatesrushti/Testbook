import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Star, StarHalf } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="hero-gradient py-12 lg:py-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 mb-8 lg:mb-0">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Prepare for Your Next Exam with Confidence
            </h1>
            <p className="text-lg text-gray-700 mb-6">
              Access thousands of mock tests, courses, and study materials to ace your competitive exams. Start your success journey today!
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild className="bg-primary hover:bg-primary/90 text-white px-6 py-6 h-auto" size="lg">
                <Link href="/courses">Explore Courses</Link>
              </Button>
              <Button asChild variant="outline" className="border-primary text-primary hover:bg-primary/10 px-6 py-6 h-auto" size="lg">
                <Link href="/mock-tests">Take Free Test</Link>
              </Button>
            </div>
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-2">
                <img 
                  className="w-10 h-10 rounded-full border-2 border-white" 
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100" 
                  alt="User avatar" 
                />
                <img 
                  className="w-10 h-10 rounded-full border-2 border-white" 
                  src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100" 
                  alt="User avatar" 
                />
                <img 
                  className="w-10 h-10 rounded-full border-2 border-white" 
                  src="https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100" 
                  alt="User avatar" 
                />
              </div>
              <div className="ml-4">
                <div className="flex items-center mb-1">
                  <div className="text-yellow-400 flex">
                    <Star className="fill-current" size={16} />
                    <Star className="fill-current" size={16} />
                    <Star className="fill-current" size={16} />
                    <Star className="fill-current" size={16} />
                    <StarHalf className="fill-current" size={16} />
                  </div>
                  <span className="ml-2 text-gray-600 font-medium">4.8/5</span>
                </div>
                <p className="text-sm text-gray-600">From 5,000+ student reviews</p>
              </div>
            </div>
          </div>
          <div className="lg:w-1/2 lg:pl-12">
            <img 
              src="https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&h=500" 
              alt="Student studying with laptop" 
              className="rounded-lg shadow-xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
