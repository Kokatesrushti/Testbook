import React from 'react';
import { Link } from 'wouter';
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube, 
  Linkedin, 
  Phone
} from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-4">EduTest</h2>
            <p className="text-gray-400 mb-6">
              India's leading online platform for competitive exam preparation. Access quality education anytime, anywhere.
            </p>
            <div className="flex space-x-4 mb-6">
              <a href="#" aria-label="Facebook" className="text-gray-400 hover:text-white">
                <Facebook size={20} />
              </a>
              <a href="#" aria-label="Twitter" className="text-gray-400 hover:text-white">
                <Twitter size={20} />
              </a>
              <a href="#" aria-label="Instagram" className="text-gray-400 hover:text-white">
                <Instagram size={20} />
              </a>
              <a href="#" aria-label="Youtube" className="text-gray-400 hover:text-white">
                <Youtube size={20} />
              </a>
              <a href="#" aria-label="LinkedIn" className="text-gray-400 hover:text-white">
                <Linkedin size={20} />
              </a>
            </div>
            <div className="flex items-center">
              <Phone className="mr-2 text-primary" size={16} />
              <span>Toll Free: 1800-123-4567</span>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Popular Exams</h3>
            <ul className="space-y-2">
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Banking Exams</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">SSC Exams</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Railway Exams</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">JEE & NEET</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">UPSC CSE</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Teaching Exams</a></Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="#"><a className="text-gray-400 hover:text-white">About Us</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Contact Us</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Careers</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Blog</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Terms & Conditions</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Privacy Policy</a></Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Help & Support</h3>
            <ul className="space-y-2">
              <li><Link href="#"><a className="text-gray-400 hover:text-white">FAQs</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Payment Options</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Refund Policy</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Customer Support</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Technical Issues</a></Link></li>
              <li><Link href="#"><a className="text-gray-400 hover:text-white">Academic Support</a></Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-gray-400">© {new Date().getFullYear()} EduTest. All rights reserved.</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="h-6 w-10 bg-gray-700 rounded"></div>
            <div className="h-6 w-10 bg-gray-700 rounded"></div>
            <div className="h-6 w-10 bg-gray-700 rounded"></div>
            <div className="h-6 w-10 bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
