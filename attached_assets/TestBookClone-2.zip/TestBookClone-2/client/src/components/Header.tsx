import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/hooks/useAuth';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { getAcronym } from '@/lib/utils';
import { 
  Search, 
  Menu, 
  Phone, 
  Mail, 
  ChevronDown, 
  Download, 
  HelpCircle,
  LogOut,
  User
} from 'lucide-react';

const Header: React.FC = () => {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search functionality would go here
    console.log("Searching for:", searchQuery);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto">
        {/* Top navigation with auth and support */}
        <div className="hidden lg:flex justify-between items-center py-2 text-sm border-b border-gray-100">
          <div className="flex items-center space-x-4">
            <a href="tel:+1234567890" className="text-gray-600 hover:text-primary flex items-center">
              <Phone size={14} className="mr-1 text-primary" />
              +1 (234) 567-8900
            </a>
            <a href="mailto:support@edutest.com" className="text-gray-600 hover:text-primary flex items-center">
              <Mail size={14} className="mr-1 text-primary" />
              support@edutest.com
            </a>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="#">
              <a className="text-gray-600 hover:text-primary">Download App</a>
            </Link>
            <Link href="#">
              <a className="text-gray-600 hover:text-primary">Support</a>
            </Link>
            <div className="border-l border-gray-200 h-4 mx-2"></div>
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="p-0 h-auto">
                    <Avatar className="h-8 w-8">
                      {user?.profilePicture ? (
                        <img src={user.profilePicture} alt={user.name} />
                      ) : (
                        <AvatarFallback>{getAcronym(user?.name || "User")}</AvatarFallback>
                      )}
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard">
                      <a className="flex items-center">
                        <User size={16} className="mr-2" />
                        Dashboard
                      </a>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={logout}>
                    <LogOut size={16} className="mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Link href="/login">
                  <a className="text-primary hover:text-primary/90">Log in</a>
                </Link>
                <Link href="/register">
                  <a className="bg-primary text-white px-3 py-1 rounded hover:bg-primary/90">Sign up</a>
                </Link>
              </>
            )}
          </div>
        </div>
        
        {/* Main navigation */}
        <nav className="py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/">
              <a className="text-2xl font-bold text-primary mr-8">
                EduTest
              </a>
            </Link>
            <div className="hidden lg:flex items-center space-x-6">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    className={`flex items-center ${location.startsWith('/exams') ? 'text-primary' : 'text-gray-700'}`}
                  >
                    Exams <ChevronDown size={16} className="ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <div className="grid grid-cols-2 gap-2 p-2 w-64">
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>Banking Exams</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>Civil Services</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>Engineering</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>Defence</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>Teaching</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>State Exams</a></Link>
                    </DropdownMenuItem>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    className={`flex items-center ${location.startsWith('/courses') ? 'text-primary' : 'text-gray-700'}`}
                  >
                    Courses <ChevronDown size={16} className="ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <div className="grid grid-cols-2 gap-2 p-2 w-64">
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>Bank & Insurance</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>SSC & Railways</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>JEE & NEET</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>GATE & ESE</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>UPSC</a></Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="#"><a>State PCS</a></Link>
                    </DropdownMenuItem>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Link href="/mock-tests">
                <a className={`${location === '/mock-tests' ? 'text-primary' : 'text-gray-700'} hover:text-primary`}>
                  Mock Tests
                </a>
              </Link>
              
              <Link href="#">
                <a className="text-gray-700 hover:text-primary">Previous Year Papers</a>
              </Link>
              
              <Link href="#">
                <a className="text-gray-700 hover:text-primary">Practice</a>
              </Link>
            </div>
          </div>
          
          <div className="flex items-center">
            <div className="hidden lg:block relative mr-4">
              <form onSubmit={handleSearch}>
                <Input
                  type="text"
                  placeholder="Search courses, tests, etc."
                  className="pl-10 pr-4 py-2 w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </form>
            </div>
            
            <Button variant="ghost" size="icon" className="lg:hidden">
              <Search className="h-5 w-5" />
            </Button>
            
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="ml-4 lg:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col h-full">
                  <div className="py-4">
                    <Link href="/">
                      <a className="text-2xl font-bold text-primary">EduTest</a>
                    </Link>
                  </div>
                  
                  <nav className="flex-1">
                    <ul className="space-y-4">
                      <li>
                        <Link href="/mock-tests">
                          <a className="block py-2 text-base font-medium">Mock Tests</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="/courses">
                          <a className="block py-2 text-base font-medium">Courses</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="#">
                          <a className="block py-2 text-base font-medium">Exams</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="#">
                          <a className="block py-2 text-base font-medium">Previous Year Papers</a>
                        </Link>
                      </li>
                      <li>
                        <Link href="#">
                          <a className="block py-2 text-base font-medium">Practice</a>
                        </Link>
                      </li>
                    </ul>
                  </nav>
                  
                  <div className="py-4 border-t border-gray-200">
                    {isAuthenticated ? (
                      <>
                        <Link href="/dashboard">
                          <a className="block py-2 text-base font-medium">Dashboard</a>
                        </Link>
                        <button 
                          onClick={logout}
                          className="w-full text-left py-2 text-base font-medium text-red-600"
                        >
                          Logout
                        </button>
                      </>
                    ) : (
                      <div className="space-y-3">
                        <Link href="/login">
                          <a className="block w-full py-2 text-center text-primary border border-primary rounded-md">
                            Log in
                          </a>
                        </Link>
                        <Link href="/register">
                          <a className="block w-full py-2 text-center text-white bg-primary rounded-md">
                            Sign up
                          </a>
                        </Link>
                      </div>
                    )}
                  </div>
                  
                  <div className="py-4 border-t border-gray-200">
                    <div className="flex items-center space-x-4">
                      <a href="#" className="flex items-center text-sm text-gray-600">
                        <Download size={16} className="mr-1" />
                        Download App
                      </a>
                      <a href="#" className="flex items-center text-sm text-gray-600">
                        <HelpCircle size={16} className="mr-1" />
                        Support
                      </a>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
