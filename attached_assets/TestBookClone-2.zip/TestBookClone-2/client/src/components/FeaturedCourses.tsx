import React, { useState } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Course } from '@shared/schema';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn, formatPrice, getCategoryColorClass } from '@/lib/utils';
import CourseCard from '@/components/CourseCard';

const FeaturedCourses: React.FC = () => {
  const [activeTab, setActiveTab] = useState('all');
  
  const { data: courses, isLoading, error } = useQuery({
    queryKey: ['/api/courses'],
  });

  const handlePrevious = () => {
    // Implement slider previous functionality
    console.log('Previous clicked');
  };

  const handleNext = () => {
    // Implement slider next functionality
    console.log('Next clicked');
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    // Here you would fetch courses by category if needed
  };

  // Filter courses based on active tab
  const filteredCourses = React.useMemo(() => {
    if (!courses || !Array.isArray(courses)) return [];
    
    if (activeTab === 'all') return courses;
    
    // This is a simplified example - in a real app you'd match by categoryId
    return courses.filter((course: Course) => {
      // Match category slug with active tab
      if (activeTab === 'banking' && course.categoryId === 1) return true;
      if (activeTab === 'ssc' && course.categoryId === 2) return true;
      if (activeTab === 'railways' && course.categoryId === 2) return true;
      if (activeTab === 'jee-neet' && course.categoryId === 3) return true;
      if (activeTab === 'upsc' && course.categoryId === 4) return true;
      return false;
    });
  }, [courses, activeTab]);

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <p>Loading courses...</p>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center text-red-500">
            <p>Error loading courses. Please try again later.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Courses</h2>
            <p className="text-lg text-gray-600">Comprehensive learning programs designed by industry experts</p>
          </div>
          <div className="mt-4 md:mt-0 flex space-x-1">
            <Button
              variant="default"
              size="icon"
              className="rounded-l-md"
              onClick={handlePrevious}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="default"
              size="icon"
              className="rounded-r-md"
              onClick={handleNext}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Course navigation tabs */}
        <div className="mb-8 border-b border-gray-200">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="h-auto p-0 bg-transparent">
              <TabsTrigger
                value="all"
                className={cn(
                  "py-3 px-4 font-medium rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary",
                )}
              >
                All Courses
              </TabsTrigger>
              <TabsTrigger
                value="banking"
                className={cn(
                  "py-3 px-4 font-medium rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary",
                )}
              >
                Banking
              </TabsTrigger>
              <TabsTrigger
                value="ssc"
                className={cn(
                  "py-3 px-4 font-medium rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary",
                )}
              >
                SSC
              </TabsTrigger>
              <TabsTrigger
                value="railways"
                className={cn(
                  "py-3 px-4 font-medium rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary",
                )}
              >
                Railways
              </TabsTrigger>
              <TabsTrigger
                value="jee-neet"
                className={cn(
                  "py-3 px-4 font-medium rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary",
                )}
              >
                JEE & NEET
              </TabsTrigger>
              <TabsTrigger
                value="upsc"
                className={cn(
                  "py-3 px-4 font-medium rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary",
                )}
              >
                UPSC
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredCourses.map((course: Course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
        
        <div className="text-center mt-10">
          <Button asChild variant="outline" className="border-primary text-primary hover:bg-primary/10">
            <Link href="/courses">View All Courses</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedCourses;
