import React from 'react';
import { BookOpen, ClipboardCheck, TrendingUp, Users } from 'lucide-react';

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  colorClass: string;
}

const Feature: React.FC<FeatureProps> = ({ icon, title, description, colorClass }) => {
  return (
    <div className="text-center p-6 border border-gray-100 rounded-lg shadow-sm hover:shadow-md transition-shadow">
      <div className={`w-16 h-16 mx-auto mb-4 flex items-center justify-center ${colorClass} rounded-full`}>
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const Features: React.FC = () => {
  const features = [
    {
      icon: <BookOpen className="text-primary text-2xl" />,
      title: "Comprehensive Courses",
      description: "Expert-designed courses covering all topics with in-depth explanations.",
      colorClass: "bg-primary/10 text-primary"
    },
    {
      icon: <ClipboardCheck className="text-secondary text-2xl" />,
      title: "Realistic Mock Tests",
      description: "Exam-like environment with timed tests and detailed performance analysis.",
      colorClass: "bg-secondary/10 text-secondary"
    },
    {
      icon: <TrendingUp className="text-accent text-2xl" />,
      title: "Progress Tracking",
      description: "Monitor your performance with detailed analytics and improvement suggestions.",
      colorClass: "bg-accent/10 text-accent"
    },
    {
      icon: <Users className="text-purple-600 text-2xl" />,
      title: "Expert Support",
      description: "Get your doubts cleared by experienced educators and mentors.",
      colorClass: "bg-purple-100 text-purple-600"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose EduTest?</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our platform offers everything you need to succeed in competitive exams with comprehensive resources and tools.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Feature
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              colorClass={feature.colorClass}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
