import React from 'react';
import { Link } from 'wouter';
import { Course } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star } from 'lucide-react';
import { formatPrice, getCategoryColorClass } from '@/lib/utils';

interface CourseCardProps {
  course: Course;
}

const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  // Map category IDs to category names (simplified example)
  const getCategoryInfo = (categoryId: number) => {
    const categories: Record<number, { name: string; color: string }> = {
      1: { name: 'Banking', color: 'blue' },
      2: { name: 'SSC', color: 'red' },
      3: { name: 'JEE', color: 'green' },
      4: { name: 'UPSC', color: 'purple' }
    };
    
    return categories[categoryId] || { name: 'Other', color: 'gray' };
  };
  
  const categoryInfo = getCategoryInfo(course.categoryId);
  const { bg, text } = getCategoryColorClass(categoryInfo.color);
  
  return (
    <div className="course-card bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className="relative">
        <img 
          src={course.image} 
          alt={course.title} 
          className="w-full h-40 object-cover"
        />
        {course.isBestSeller && (
          <div className="absolute top-0 right-0 bg-primary text-white text-xs font-bold px-2 py-1 m-2 rounded">
            Best Seller
          </div>
        )}
        {course.isNew && (
          <div className="absolute top-0 right-0 bg-green-600 text-white text-xs font-bold px-2 py-1 m-2 rounded">
            New
          </div>
        )}
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <Badge variant="secondary" className={`${bg} ${text}`}>
            {categoryInfo.name}
          </Badge>
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-400 fill-current" />
            <span className="text-sm ml-1 text-gray-700">{(course.rating / 10).toFixed(1)}</span>
          </div>
        </div>
        <h3 className="font-semibold text-lg mb-2 text-gray-900">{course.title}</h3>
        <p className="text-gray-600 text-sm mb-4">{course.description}</p>
        <div className="flex justify-between items-center">
          <div className="text-primary font-bold">
            {formatPrice(course.price)} 
            <span className="text-gray-400 line-through text-sm font-normal ml-1">
              {formatPrice(course.originalPrice)}
            </span>
          </div>
          <Button asChild size="sm">
            <Link href={`/courses/${course.slug}`}>Enroll Now</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;
