import React, { useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

const FAQSection: React.FC = () => {
  const faqItems: FAQItem[] = [
    {
      id: "faq-1",
      question: "How can I access the courses after enrollment?",
      answer: "After enrollment, you can access your courses by logging into your account. All your enrolled courses will be available on your dashboard. You can also access them through our mobile app."
    },
    {
      id: "faq-2",
      question: "What is the validity period of the courses?",
      answer: "Most of our courses have a validity period of 12 months from the date of enrollment. Premium courses may have extended validity. The specific validity period is mentioned on each course page."
    },
    {
      id: "faq-3",
      question: "Do you provide study materials along with video lectures?",
      answer: "Yes, all our courses include comprehensive study materials, PDFs, and notes along with video lectures. You can download these materials for offline study."
    },
    {
      id: "faq-4",
      question: "How do I get my doubts cleared?",
      answer: "We offer doubt clearing sessions through our Q&A forum, where experts answer your questions within 24 hours. Premium courses also include live doubt clearing sessions with faculty members."
    },
    {
      id: "faq-5",
      question: "Can I access the content on multiple devices?",
      answer: "Yes, you can access your enrolled courses on up to 3 devices simultaneously. Our platform is compatible with desktop, laptop, tablet, and mobile devices."
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Find answers to common questions about our platform
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqItems.map((faq) => (
              <AccordionItem key={faq.id} value={faq.id} className="border-b border-gray-200 py-4">
                <AccordionTrigger className="text-lg font-semibold text-gray-900">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
