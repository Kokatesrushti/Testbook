import React from 'react';
import { Star } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  achievement: string;
  image: string;
  content: string;
  rating: number;
}

const SuccessStories: React.FC = () => {
  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "Rahul Sharma",
      achievement: "SBI PO 2022 - AIR 45",
      image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100",
      content: "The mock tests and study material on EduTest were incredibly helpful. The detailed solutions and performance analysis helped me identify my weak areas. I owe my success to the structured preparation approach.",
      rating: 5
    },
    {
      id: 2,
      name: "Priya Patel",
      achievement: "SSC CGL 2022 - AIR 78",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100",
      content: "EduTest's SSC course was comprehensive and covered all topics in depth. The live classes and doubt clearing sessions were extremely useful. I highly recommend their test series to all SSC aspirants.",
      rating: 5
    },
    {
      id: 3,
      name: "Amit Verma",
      achievement: "JEE Advanced 2022 - AIR 156",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100",
      content: "The JEE Advanced course on EduTest helped me understand complex concepts with ease. The problem-solving approach and tips from experienced faculty made a huge difference in my preparation.",
      rating: 4.5
    }
  ];

  // Render stars based on rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="fill-current" />);
    }
    
    if (hasHalfStar) {
      stars.push(
        <svg key="half" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star-half fill-current">
          <path d="M12 17.8 5.8 21 7 14.1 2 9.3l7-1L12 2" fill="currentColor" />
          <path d="M12 17.8 18.2 21 17 14.1 22 9.3l-7-1L12 2" />
        </svg>
      );
    }
    
    return (
      <div className="flex text-yellow-400">
        {stars}
      </div>
    );
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Success Stories</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our students have achieved remarkable success in various competitive exams
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-4">
                <img 
                  src={testimonial.image} 
                  alt={`${testimonial.name} portrait`} 
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">{testimonial.name}</h3>
                  <p className="text-sm text-primary">{testimonial.achievement}</p>
                </div>
              </div>
              <p className="text-gray-600 mb-4">
                "{testimonial.content}"
              </p>
              {renderStars(testimonial.rating)}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;
