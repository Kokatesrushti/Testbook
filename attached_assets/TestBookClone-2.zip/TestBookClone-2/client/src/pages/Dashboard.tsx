import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/hooks/useAuth';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { Badge } from '@/components/ui/badge';
import { Clock, Calendar, Book, CheckCircle, Award } from 'lucide-react';
import { formatPrice, formatDuration } from '@/lib/utils';
import CourseCard from '@/components/CourseCard';
import TestCard from '@/components/TestCard';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch user's enrollments
  const { data: enrollments, isLoading: enrollmentsLoading } = useQuery({
    queryKey: ['/api/enrollments'],
  });

  // Fetch user's test attempts
  const { data: testAttempts, isLoading: attemptsLoading } = useQuery({
    queryKey: ['/api/test-attempts'],
  });

  // Calculate dashboard stats
  const dashboardStats = React.useMemo(() => {
    if (!enrollments || !testAttempts) return {
      enrolledCourses: 0,
      completedCourses: 0,
      totalTestsAttempted: 0,
      averageTestScore: 0,
      completionRate: 0,
    };

    const enrolledCourses = enrollments.length;
    const completedCourses = enrollments.filter((e: any) => e.isCompleted).length;
    const totalTestsAttempted = testAttempts.length;
    
    // Calculate average test score
    const totalScore = testAttempts.reduce((sum: number, attempt: any) => {
      return sum + (attempt.score / attempt.totalQuestions) * 100;
    }, 0);
    const averageTestScore = totalTestsAttempted > 0 ? totalScore / totalTestsAttempted : 0;
    
    // Calculate course completion rate
    const completionRate = enrolledCourses > 0 ? (completedCourses / enrolledCourses) * 100 : 0;

    return {
      enrolledCourses,
      completedCourses,
      totalTestsAttempted,
      averageTestScore,
      completionRate,
    };
  }, [enrollments, testAttempts]);

  // Prepare chart data for performance
  const performanceData = React.useMemo(() => {
    if (!testAttempts || !Array.isArray(testAttempts)) return [];
    
    return testAttempts.slice(0, 5).map((attempt: any) => ({
      name: attempt.test?.title || `Test #${attempt.id}`,
      score: Math.round((attempt.score / attempt.totalQuestions) * 100),
    }));
  }, [testAttempts]);

  // Prepare pie chart data for subject breakdown
  const subjectBreakdownData = [
    { name: 'Mathematics', value: 68 },
    { name: 'English', value: 82 },
    { name: 'Reasoning', value: 74 },
    { name: 'General Knowledge', value: 92 },
  ];

  const COLORS = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)'];

  if (enrollmentsLoading || attemptsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard - EduTest</title>
        <meta name="description" content="Access your EduTest dashboard to track your progress, enrolled courses, and test performance." />
      </Helmet>
      
      <div className="bg-gray-50 py-8 px-4 md:py-12">
        <div className="container mx-auto">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
              <p className="text-gray-600">Welcome back, {user?.name || 'Student'}</p>
            </div>
            <div className="mt-4 sm:mt-0">
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary">
                Student
              </Badge>
            </div>
          </div>
          
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="courses">My Courses</TabsTrigger>
              <TabsTrigger value="tests">Test History</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Enrolled Courses</CardTitle>
                    <Book className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{dashboardStats.enrolledCourses}</div>
                    <p className="text-xs text-muted-foreground">
                      {dashboardStats.completedCourses} completed
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Tests Attempted</CardTitle>
                    <CheckCircle className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{dashboardStats.totalTestsAttempted}</div>
                    <p className="text-xs text-muted-foreground">
                      Last attempt: {testAttempts && testAttempts.length > 0 ? 
                        new Date(testAttempts[0]?.completedAt).toLocaleDateString() : 
                        'No attempts yet'}
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Average Score</CardTitle>
                    <Award className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {dashboardStats.averageTestScore.toFixed(1)}%
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {dashboardStats.averageTestScore >= 70 ? 'Excellent!' : 
                       dashboardStats.averageTestScore >= 50 ? 'Good progress' : 
                       'Needs improvement'}
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{dashboardStats.completionRate.toFixed(0)}%</div>
                    <Progress value={dashboardStats.completionRate} className="mt-2" />
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Recent Performance</CardTitle>
                    <CardDescription>Your performance in the last 5 tests</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {performanceData.length > 0 ? (
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={performanceData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                            <YAxis tick={{ fontSize: 12 }} />
                            <Tooltip />
                            <Bar dataKey="score" fill="hsl(var(--primary))" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-[300px] text-center">
                        <p className="text-muted-foreground mb-2">No test attempts yet</p>
                        <p className="text-sm text-muted-foreground">
                          Take some mock tests to see your performance here
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Subject-wise Performance</CardTitle>
                    <CardDescription>Your performance across different subjects</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={subjectBreakdownData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {subjectBreakdownData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="courses">
              <Card>
                <CardHeader>
                  <CardTitle>My Enrolled Courses</CardTitle>
                  <CardDescription>
                    Track your progress in your enrolled courses
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {enrollments && enrollments.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {enrollments.map((enrollment: any) => (
                        <div key={enrollment.id} className="border rounded-lg overflow-hidden">
                          <div className="relative">
                            <img 
                              src={enrollment.course?.image} 
                              alt={enrollment.course?.title} 
                              className="w-full h-40 object-cover"
                            />
                            <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-2">
                              <div className="flex justify-between items-center">
                                <span className="text-sm">Progress</span>
                                <span className="text-sm">{enrollment.progress}%</span>
                              </div>
                              <Progress value={enrollment.progress} className="mt-1" />
                            </div>
                          </div>
                          <div className="p-4">
                            <h3 className="font-semibold text-lg mb-2">{enrollment.course?.title}</h3>
                            <div className="flex justify-between items-center">
                              <Badge variant={enrollment.isCompleted ? "success" : "secondary"}>
                                {enrollment.isCompleted ? "Completed" : "In Progress"}
                              </Badge>
                              <span className="text-sm text-gray-500">
                                Enrolled: {new Date(enrollment.enrolledAt).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground mb-4">You haven't enrolled in any courses yet</p>
                      <a href="/courses" className="text-primary hover:underline">Browse courses</a>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="tests">
              <Card>
                <CardHeader>
                  <CardTitle>Test History</CardTitle>
                  <CardDescription>
                    View your test attempts and scores
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {testAttempts && testAttempts.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="bg-muted">
                            <th className="p-2 text-left text-muted-foreground font-medium">Test Name</th>
                            <th className="p-2 text-left text-muted-foreground font-medium">Date</th>
                            <th className="p-2 text-left text-muted-foreground font-medium">Score</th>
                            <th className="p-2 text-left text-muted-foreground font-medium">Time Spent</th>
                            <th className="p-2 text-left text-muted-foreground font-medium">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {testAttempts.map((attempt: any) => {
                            const scorePercentage = (attempt.score / attempt.totalQuestions) * 100;
                            return (
                              <tr key={attempt.id} className="border-b last:border-0">
                                <td className="p-2">{attempt.test?.title || `Test #${attempt.id}`}</td>
                                <td className="p-2">{new Date(attempt.completedAt).toLocaleDateString()}</td>
                                <td className="p-2">
                                  {attempt.score}/{attempt.totalQuestions} ({scorePercentage.toFixed(1)}%)
                                </td>
                                <td className="p-2">{formatDuration(Math.floor(attempt.timeSpent / 60))}</td>
                                <td className="p-2">
                                  <Badge variant={scorePercentage >= 70 ? "success" : 
                                          scorePercentage >= 40 ? "secondary" : "destructive"}>
                                    {scorePercentage >= 70 ? "Excellent" : 
                                     scorePercentage >= 40 ? "Good" : "Needs Improvement"}
                                  </Badge>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground mb-4">You haven't attempted any tests yet</p>
                      <a href="/mock-tests" className="text-primary hover:underline">Take a mock test</a>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="performance">
              <div className="grid grid-cols-1 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Analysis</CardTitle>
                    <CardDescription>
                      Detailed breakdown of your performance across different subjects and topics
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[400px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={[
                          { name: 'Mathematics', correct: 68, incorrect: 32 },
                          { name: 'English', correct: 82, incorrect: 18 },
                          { name: 'Reasoning', correct: 74, incorrect: 26 },
                          { name: 'General Knowledge', correct: 92, incorrect: 8 },
                        ]}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis label={{ value: 'Percentage (%)', angle: -90, position: 'insideLeft' }} />
                          <Tooltip />
                          <Legend />
                          <Bar name="Correct Answers" dataKey="correct" fill="hsl(var(--primary))" />
                          <Bar name="Incorrect Answers" dataKey="incorrect" fill="hsl(var(--destructive))" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <div className="mt-8">
                      <h3 className="text-lg font-semibold mb-4">Improvement Areas</h3>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">Mathematics - Algebra</span>
                            <span className="text-sm font-medium">42%</span>
                          </div>
                          <Progress value={42} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">Reasoning - Logical Deduction</span>
                            <span className="text-sm font-medium">58%</span>
                          </div>
                          <Progress value={58} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">English - Grammar</span>
                            <span className="text-sm font-medium">65%</span>
                          </div>
                          <Progress value={65} className="h-2" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
