import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MockTest } from '@shared/schema';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Helmet } from 'react-helmet';
import TestCard from '@/components/TestCard';
import { Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const MockTests: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showFreeOnly, setShowFreeOnly] = useState(false);

  // Fetch all mock tests
  const { data: tests, isLoading, error } = useQuery({
    queryKey: ['/api/mock-tests'],
  });

  // Fetch categories for filter
  const { data: categories } = useQuery({
    queryKey: ['/api/categories'],
  });

  // Filter mock tests
  const filteredTests = React.useMemo(() => {
    if (!tests || !Array.isArray(tests)) return [];
    
    // First filter by search query
    let result = tests.filter((test: MockTest) => 
      test.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    // Then filter by category
    if (categoryFilter !== 'all') {
      result = result.filter((test: MockTest) => {
        // Find category with matching slug
        const category = categories?.find(cat => cat.slug === categoryFilter);
        return category ? test.categoryId === category.id : false;
      });
    }
    
    // Filter by free/paid status if needed
    if (showFreeOnly) {
      result = result.filter((test: MockTest) => test.isFree);
    }
    
    // Sort by attempt count (popularity)
    return result.sort((a: MockTest, b: MockTest) => b.attemptCount - a.attemptCount);
  }, [tests, searchQuery, categoryFilter, showFreeOnly, categories]);

  return (
    <>
      <Helmet>
        <title>Mock Tests - EduTest</title>
        <meta name="description" content="Practice with our exam-like mock tests to evaluate your preparation level. Find free and premium mock tests for all competitive exams." />
      </Helmet>
      
      <div className="bg-gray-50 py-8 px-4 md:py-12">
        <div className="container mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Mock Tests</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Practice with our exam-like mock tests to evaluate your preparation level
            </p>
          </div>
          
          {/* Search and filters */}
          <div className="mb-8 bg-white p-6 rounded-lg shadow-sm">
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  className="pl-10"
                  placeholder="Search mock tests"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories && Array.isArray(categories) && categories.map((category: any) => (
                      <SelectItem key={category.id} value={category.slug}>{category.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Button 
                  variant={showFreeOnly ? "default" : "outline"}
                  onClick={() => setShowFreeOnly(!showFreeOnly)}
                >
                  {showFreeOnly ? "Showing Free Only" : "Show All Tests"}
                </Button>
              </div>
            </div>
            
            {/* Category quick filters */}
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCategoryFilter('all')}
                className={cn(
                  categoryFilter === 'all' ? 'bg-primary/10 text-primary border-primary' : ''
                )}
              >
                All Tests
              </Button>
              {categories && Array.isArray(categories) && categories.slice(0, 5).map((category: any) => (
                <Button
                  key={category.id}
                  variant="outline"
                  size="sm"
                  onClick={() => setCategoryFilter(category.slug)}
                  className={cn(
                    categoryFilter === category.slug ? 'bg-primary/10 text-primary border-primary' : ''
                  )}
                >
                  {category.name}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Tests grid */}
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading mock tests...</p>
            </div>
          ) : error ? (
            <div className="text-center py-12">
              <p className="text-red-500">Error loading mock tests. Please try again later.</p>
            </div>
          ) : (
            <>
              {filteredTests.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredTests.map((test: MockTest) => (
                    <TestCard key={test.id} test={test} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No mock tests found</h3>
                  <p className="text-gray-600">
                    Try adjusting your search or filter criteria to find what you're looking for.
                  </p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default MockTests;
