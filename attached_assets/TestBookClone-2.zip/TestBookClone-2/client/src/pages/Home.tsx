import React from 'react';
import Hero from '@/components/Hero';
import Features from '@/components/Features';
import ExamCategories from '@/components/ExamCategories';
import FeaturedCourses from '@/components/FeaturedCourses';
import MockTestSection from '@/components/MockTestSection';
import TestSeriesSection from '@/components/TestSeriesSection';
import SuccessStories from '@/components/SuccessStories';
import AppDownload from '@/components/AppDownload';
import FAQSection from '@/components/FAQSection';
import { Helmet } from 'react-helmet';

const Home: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>EduTest - Online Test Preparation Platform</title>
        <meta name="description" content="Prepare for competitive exams with EduTest. Access high-quality courses, mock tests, and study materials to boost your exam preparation." />
        <meta property="og:title" content="EduTest - Online Test Preparation Platform" />
        <meta property="og:description" content="Prepare for competitive exams with EduTest. Access high-quality courses, mock tests, and study materials to boost your exam preparation." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://edutest.com" />
      </Helmet>
      
      <Hero />
      <Features />
      <ExamCategories />
      <FeaturedCourses />
      <MockTestSection />
      <TestSeriesSection />
      <SuccessStories />
      <AppDownload />
      <FAQSection />
    </>
  );
};

export default Home;
