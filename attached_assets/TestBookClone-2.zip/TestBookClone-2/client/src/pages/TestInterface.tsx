import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Helmet } from 'react-helmet';
import { useToast } from '@/hooks/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { CheckCircle, Clock, AlertTriangle, ChevronLeft, ChevronRight, Flag } from 'lucide-react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';

interface TestParams {
  slug: string;
}

interface Question {
  id: number;
  content: string;
  options: string[];
  correctOption: number;
  explanation?: string;
}

const TestInterface: React.FC<{ slug: string }> = ({ slug }) => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State for test
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<number[]>([]);
  const [timeRemaining, setTimeRemaining] = useState<number>(0);
  const [testStartTime, setTestStartTime] = useState<Date>(new Date());
  const [isSubmitDialogOpen, setIsSubmitDialogOpen] = useState(false);
  const [testSubmitted, setTestSubmitted] = useState(false);
  const [testResult, setTestResult] = useState<{
    score: number;
    totalQuestions: number;
    timeSpent: number;
    answers: Record<number, number>;
  } | null>(null);

  // Fetch test details
  const { data: test, isLoading: testLoading, error: testError } = useQuery({
    queryKey: [`/api/mock-tests/${slug}`],
  });

  // Fetch test questions
  const { data: questions, isLoading: questionsLoading, error: questionsError } = useQuery({
    queryKey: [`/api/mock-tests/${test?.id}/questions`],
    enabled: !!test?.id,
  });

  // Set up timer when test data is loaded
  useEffect(() => {
    if (test && !testSubmitted) {
      setTimeRemaining(test.duration * 60); // convert minutes to seconds
      
      const timer = setInterval(() => {
        setTimeRemaining(prevTime => {
          if (prevTime <= 1) {
            clearInterval(timer);
            submitTest();
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [test, testSubmitted]);

  // Initialize answers object when questions are loaded
  useEffect(() => {
    if (questions && Array.isArray(questions)) {
      const initialAnswers: Record<number, number> = {};
      questions.forEach((question: Question) => {
        initialAnswers[question.id] = -1; // -1 indicates unanswered
      });
      setUserAnswers(initialAnswers);
    }
  }, [questions]);

  // Format time remaining into MM:SS
  const formatTimeRemaining = () => {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Submit test mutation
  const submitTestMutation = useMutation({
    mutationFn: async (data: {
      testId: number;
      score: number;
      totalQuestions: number;
      answers: Record<number, number>;
      timeSpent: number;
    }) => {
      const response = await apiRequest('POST', '/api/test-attempts', data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Test submitted successfully",
        description: `Your score: ${data.score}/${data.totalQuestions}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/test-attempts'] });
      setTestResult(data);
    },
    onError: (error: Error) => {
      toast({
        title: "Error submitting test",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    }
  });

  // Handle answer selection
  const handleAnswerSelect = (questionId: number, optionIndex: number) => {
    setUserAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  // Navigate to next or previous question
  const goToQuestion = (index: number) => {
    if (index >= 0 && questions && index < questions.length) {
      setCurrentQuestionIndex(index);
    }
  };

  // Toggle flagged status for current question
  const toggleFlagQuestion = (questionId: number) => {
    setFlaggedQuestions(prev => {
      if (prev.includes(questionId)) {
        return prev.filter(id => id !== questionId);
      } else {
        return [...prev, questionId];
      }
    });
  };

  // Calculate test statistics
  const getTestStats = () => {
    if (!questions || !Array.isArray(questions)) return { 
      answered: 0, 
      flagged: 0, 
      unanswered: 0 
    };
    
    const answered = Object.values(userAnswers).filter(answer => answer !== -1).length;
    const flagged = flaggedQuestions.length;
    const unanswered = questions.length - answered;
    
    return { answered, flagged, unanswered };
  };

  // Calculate score based on correct answers
  const calculateScore = () => {
    if (!questions || !Array.isArray(questions)) return 0;
    
    let score = 0;
    questions.forEach((question: Question) => {
      if (userAnswers[question.id] === question.correctOption) {
        score++;
      }
    });
    
    return score;
  };

  // Submit test
  const submitTest = () => {
    if (!test || !questions || !Array.isArray(questions)) return;
    
    const timeSpent = Math.floor((new Date().getTime() - testStartTime.getTime()) / 1000);
    const score = calculateScore();
    
    submitTestMutation.mutateAsync({
      testId: test.id,
      score,
      totalQuestions: questions.length,
      answers: userAnswers,
      timeSpent
    });
    
    setTestSubmitted(true);
  };

  // Loading state
  if (testLoading || questionsLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Error state
  if (testError || questionsError || !test) {
    return (
      <div className="container mx-auto py-12 px-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-xl text-red-500">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              There was an error loading the test. Please try again later or contact support.
            </p>
            <Button 
              className="mt-4" 
              onClick={() => navigate('/mock-tests')}
            >
              Back to Mock Tests
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (testSubmitted && testResult) {
    // Show test results
    return (
      <>
        <Helmet>
          <title>Test Results - {test.title} - EduTest</title>
        </Helmet>
        
        <div className="container mx-auto py-12 px-4">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Test Results</CardTitle>
              <CardDescription>{test.title}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center mb-8">
                <div className="w-40 h-40 rounded-full border-8 border-primary flex items-center justify-center mb-6">
                  <div className="text-center">
                    <div className="text-4xl font-bold">
                      {((testResult.score / testResult.totalQuestions) * 100).toFixed(0)}%
                    </div>
                    <div className="text-sm text-gray-500">
                      {testResult.score}/{testResult.totalQuestions}
                    </div>
                  </div>
                </div>
                
                <h3 className="text-xl font-bold mb-2">
                  {testResult.score / testResult.totalQuestions >= 0.7 ? 'Excellent!' :
                   testResult.score / testResult.totalQuestions >= 0.4 ? 'Good effort!' :
                   'Keep practicing!'}
                </h3>
                <p className="text-gray-600 mb-6">
                  Time taken: {Math.floor(testResult.timeSpent / 60)} minutes {testResult.timeSpent % 60} seconds
                </p>
              </div>
              
              <div className="space-y-8">
                {questions && Array.isArray(questions) && questions.map((question: Question, index: number) => {
                  const isCorrect = userAnswers[question.id] === question.correctOption;
                  return (
                    <div 
                      key={question.id} 
                      className={`p-6 rounded-lg border ${
                        isCorrect ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'
                      }`}
                    >
                      <div className="flex gap-2 mb-4">
                        <Badge variant={isCorrect ? "success" : "destructive"}>
                          {isCorrect ? 'Correct' : 'Incorrect'}
                        </Badge>
                        <Badge variant="outline">Question {index + 1}</Badge>
                      </div>
                      
                      <div className="mb-4">
                        <h3 className="text-lg font-medium mb-2">{question.content}</h3>
                        <div className="space-y-2 ml-1">
                          {question.options.map((option, optIndex) => (
                            <div 
                              key={optIndex} 
                              className={`p-3 rounded ${
                                optIndex === question.correctOption ? 'bg-green-100 border border-green-300' :
                                optIndex === userAnswers[question.id] ? 'bg-red-100 border border-red-300' :
                                'bg-gray-100'
                              }`}
                            >
                              <div className="flex items-center">
                                <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-2 ${
                                  optIndex === question.correctOption ? 'bg-green-500 text-white' :
                                  optIndex === userAnswers[question.id] ? 'bg-red-500 text-white' :
                                  'bg-gray-300'
                                }`}>
                                  {String.fromCharCode(65 + optIndex)}
                                </div>
                                <span>{option}</span>
                                {optIndex === question.correctOption && (
                                  <CheckCircle className="ml-auto h-5 w-5 text-green-500" />
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {question.explanation && (
                        <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded">
                          <h4 className="font-medium text-blue-700 mb-1">Explanation:</h4>
                          <p className="text-blue-800">{question.explanation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button onClick={() => navigate('/mock-tests')}>
                Back to Mock Tests
              </Button>
            </CardFooter>
          </Card>
        </div>
      </>
    );
  }

  // Current question
  const currentQuestion = questions && Array.isArray(questions) && questions[currentQuestionIndex];
  const testStats = getTestStats();

  return (
    <>
      <Helmet>
        <title>{test.title} - EduTest</title>
      </Helmet>
      
      <div className="bg-gray-50 min-h-screen py-4 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Test info sidebar */}
            <div className="md:w-1/4">
              <Card className="sticky top-20">
                <CardHeader>
                  <CardTitle className="text-xl">{test.title}</CardTitle>
                  <CardDescription>
                    Total Questions: {questions?.length || 0}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Clock className="mr-2 h-5 w-5 text-muted-foreground" />
                      <span className="font-medium">Time Left:</span>
                    </div>
                    <Badge variant={timeRemaining < 300 ? "destructive" : "secondary"}>
                      {formatTimeRemaining()}
                    </Badge>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Answered</span>
                      <span className="font-medium">{testStats.answered} / {questions?.length || 0}</span>
                    </div>
                    <Progress value={(testStats.answered / (questions?.length || 1)) * 100} className="h-2" />
                    
                    <div className="flex justify-between text-sm mt-4">
                      <span>Flagged for review</span>
                      <span className="font-medium">{testStats.flagged}</span>
                    </div>
                    
                    <div className="flex justify-between text-sm mt-4">
                      <span>Unanswered</span>
                      <span className="font-medium">{testStats.unanswered}</span>
                    </div>
                  </div>
                  
                  <div className="pt-4">
                    <h3 className="font-medium mb-2">Questions</h3>
                    <div className="grid grid-cols-5 gap-2">
                      {questions && Array.isArray(questions) && questions.map((q, index) => (
                        <Button
                          key={q.id}
                          variant={currentQuestionIndex === index ? "default" : 
                                  userAnswers[q.id] !== -1 ? "secondary" : "outline"}
                          size="sm"
                          className={`${
                            flaggedQuestions.includes(q.id) ? 'border-yellow-500 border-2' : ''
                          } w-full h-9`}
                          onClick={() => goToQuestion(index)}
                        >
                          {index + 1}
                        </Button>
                      ))}
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full mt-4" 
                    variant="destructive"
                    onClick={() => setIsSubmitDialogOpen(true)}
                  >
                    Submit Test
                  </Button>
                </CardContent>
              </Card>
            </div>
            
            {/* Question panel */}
            <div className="md:w-3/4">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <Badge variant="outline" className="mb-2">
                        Question {currentQuestionIndex + 1} of {questions?.length || 0}
                      </Badge>
                      <CardTitle className="text-xl">{currentQuestion?.content}</CardTitle>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => currentQuestion && toggleFlagQuestion(currentQuestion.id)}
                      className={`${
                        currentQuestion && flaggedQuestions.includes(currentQuestion.id) 
                          ? 'text-yellow-600 border-yellow-300 bg-yellow-50 hover:bg-yellow-100 hover:text-yellow-700' 
                          : ''
                      }`}
                    >
                      <Flag className={`h-4 w-4 mr-1 ${
                        currentQuestion && flaggedQuestions.includes(currentQuestion.id) 
                          ? 'fill-yellow-500' 
                          : ''
                      }`} />
                      {currentQuestion && flaggedQuestions.includes(currentQuestion.id) 
                        ? 'Flagged' 
                        : 'Flag for Review'}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {currentQuestion && (
                    <RadioGroup
                      value={userAnswers[currentQuestion.id]?.toString() || undefined}
                      onValueChange={(value) => handleAnswerSelect(currentQuestion.id, parseInt(value))}
                    >
                      <div className="space-y-3">
                        {currentQuestion.options.map((option, idx) => (
                          <div 
                            key={idx} 
                            className={`flex items-center space-x-2 border rounded-lg p-4 hover:bg-gray-50 cursor-pointer ${
                              userAnswers[currentQuestion.id] === idx ? 'border-primary bg-primary/5' : 'border-gray-200'
                            }`}
                            onClick={() => handleAnswerSelect(currentQuestion.id, idx)}
                          >
                            <RadioGroupItem value={idx.toString()} id={`option-${idx}`} />
                            <Label htmlFor={`option-${idx}`} className="flex-grow cursor-pointer py-2">
                              <div className="flex items-center">
                                <div className="w-6 h-6 rounded-full bg-gray-200 text-gray-700 flex items-center justify-center mr-3">
                                  {String.fromCharCode(65 + idx)}
                                </div>
                                {option}
                              </div>
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button
                    variant="outline"
                    onClick={() => goToQuestion(currentQuestionIndex - 1)}
                    disabled={currentQuestionIndex === 0}
                  >
                    <ChevronLeft className="mr-1 h-4 w-4" /> Previous
                  </Button>
                  
                  <Button
                    onClick={() => goToQuestion(currentQuestionIndex + 1)}
                    disabled={currentQuestionIndex === (questions?.length || 0) - 1}
                  >
                    Next <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </div>
      </div>
      
      {/* Submit test confirmation dialog */}
      <AlertDialog open={isSubmitDialogOpen} onOpenChange={setIsSubmitDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Submit Test?</AlertDialogTitle>
            <AlertDialogDescription>
              {testStats.unanswered > 0 ? (
                <div className="flex items-start">
                  <AlertTriangle className="text-yellow-500 mr-2 mt-0.5" />
                  <span>
                    You have {testStats.unanswered} unanswered question{testStats.unanswered !== 1 ? 's' : ''}.
                    Are you sure you want to submit the test?
                  </span>
                </div>
              ) : (
                "Are you sure you want to submit your test? This action cannot be undone."
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={submitTest}>Submit Test</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default TestInterface;
