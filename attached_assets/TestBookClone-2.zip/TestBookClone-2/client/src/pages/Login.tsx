import React, { useState, useEffect } from 'react';
import { Link, useLocation, useRoute, useRouter } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Helmet } from 'react-helmet';

const loginSchema = z.object({
  username: z.string().min(3, { message: 'Username must be at least 3 characters' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
});

type LoginFormValues = z.infer<typeof loginSchema>;

const Login: React.FC = () => {
  const { login, isAuthenticated } = useAuth();
  const [isPending, setIsPending] = useState(false);
  const [location, navigate] = useLocation();
  const [, params] = useRoute('/login');
  
  // Check for redirect query param
  const searchParams = new URLSearchParams(location.split('?')[1]);
  const redirectRequired = searchParams.get('redirect') === 'true';

  // Setup form with zod validation
  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  // Handle form submission
  const onSubmit = async (values: LoginFormValues) => {
    try {
      setIsPending(true);
      await login(values.username, values.password);
      // Navigation will be handled by the useEffect
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setIsPending(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Login - EduTest</title>
        <meta name="description" content="Log in to your EduTest account to access your courses, mock tests, and track your progress." />
      </Helmet>
      
      <div className="flex justify-center items-center min-h-[calc(100vh-200px)] py-12 px-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center">Login to EduTest</CardTitle>
            <CardDescription className="text-center">
              Enter your credentials to access your account
              {redirectRequired && (
                <p className="mt-2 text-sm text-primary font-medium">
                  Please login to continue to the protected area
                </p>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your username" 
                          {...field} 
                          disabled={isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Enter your password" 
                          {...field} 
                          disabled={isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={isPending}
                >
                  {isPending ? 'Logging in...' : 'Login'}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-sm text-center">
              <span className="text-gray-600">Don't have an account?</span>{' '}
              <Link href="/register">
                <a className="text-primary hover:underline">Sign up</a>
              </Link>
            </div>
            <div className="text-xs text-center text-gray-500">
              By logging in, you agree to our{' '}
              <Link href="/terms">
                <a className="underline">Terms of Service</a>
              </Link>{' '}
              and{' '}
              <Link href="/privacy">
                <a className="underline">Privacy Policy</a>
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </>
  );
};

export default Login;
