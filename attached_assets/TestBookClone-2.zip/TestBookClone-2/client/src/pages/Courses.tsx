import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Course } from '@shared/schema';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Helmet } from 'react-helmet';
import CourseCard from '@/components/CourseCard';
import { Search, SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const Courses: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortBy, setSortBy] = useState('popularity');

  // Fetch all courses
  const { data: courses, isLoading, error } = useQuery({
    queryKey: ['/api/courses'],
  });

  // Fetch categories for filter
  const { data: categories } = useQuery({
    queryKey: ['/api/categories'],
  });

  // Filter and sort courses
  const filteredCourses = React.useMemo(() => {
    if (!courses || !Array.isArray(courses)) return [];
    
    // First filter by search query
    let result = courses.filter((course: Course) => 
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    // Then filter by category
    if (categoryFilter !== 'all') {
      result = result.filter((course: Course) => {
        // Find category with matching slug
        const category = categories?.find(cat => cat.slug === categoryFilter);
        return category ? course.categoryId === category.id : false;
      });
    }
    
    // Finally sort
    return result.sort((a: Course, b: Course) => {
      switch(sortBy) {
        case 'price-low-high':
          return a.price - b.price;
        case 'price-high-low':
          return b.price - a.price;
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'popularity':
        default:
          // Sort by a combination of reviews and bestseller status
          const aScore = (a.rating * a.reviewCount) + (a.isBestSeller ? 1000 : 0);
          const bScore = (b.rating * b.reviewCount) + (b.isBestSeller ? 1000 : 0);
          return bScore - aScore;
      }
    });
  }, [courses, searchQuery, categoryFilter, sortBy, categories]);

  return (
    <>
      <Helmet>
        <title>Courses - EduTest</title>
        <meta name="description" content="Browse our comprehensive collection of exam preparation courses. Find the perfect course to ace your competitive exams." />
      </Helmet>
      
      <div className="bg-gray-50 py-8 px-4 md:py-12">
        <div className="container mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Explore Our Courses</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Find the perfect course to help you prepare for your upcoming competitive exams
            </p>
          </div>
          
          {/* Search and filters */}
          <div className="mb-8 bg-white p-6 rounded-lg shadow-sm">
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  className="pl-10"
                  placeholder="Search courses by name or description"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories && Array.isArray(categories) && categories.map((category: any) => (
                      <SelectItem key={category.id} value={category.slug}>{category.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popularity">Popularity</SelectItem>
                    <SelectItem value="price-low-high">Price: Low to High</SelectItem>
                    <SelectItem value="price-high-low">Price: High to Low</SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Category quick filters */}
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCategoryFilter('all')}
                className={cn(
                  categoryFilter === 'all' ? 'bg-primary/10 text-primary border-primary' : ''
                )}
              >
                All
              </Button>
              {categories && Array.isArray(categories) && categories.slice(0, 5).map((category: any) => (
                <Button
                  key={category.id}
                  variant="outline"
                  size="sm"
                  onClick={() => setCategoryFilter(category.slug)}
                  className={cn(
                    categoryFilter === category.slug ? 'bg-primary/10 text-primary border-primary' : ''
                  )}
                >
                  {category.name}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Courses grid */}
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading courses...</p>
            </div>
          ) : error ? (
            <div className="text-center py-12">
              <p className="text-red-500">Error loading courses. Please try again later.</p>
            </div>
          ) : (
            <>
              {filteredCourses.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredCourses.map((course: Course) => (
                    <CourseCard key={course.id} course={course} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No courses found</h3>
                  <p className="text-gray-600">
                    Try adjusting your search or filter criteria to find what you're looking for.
                  </p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default Courses;
